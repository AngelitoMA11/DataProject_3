import base64
import json
import os
import logging
from google.cloud import bigquery
import pandas as pd

# Configuración por defecto desde variables de entorno
PROJECT_ID = os.getenv("PROJECT_ID", "dataproject3-458310")
DATASET = os.getenv("DATASET", "app_viajes")
TABLE = os.getenv("TABLE", "coches")
DEFAULT_RATE = float(os.getenv("USD_TO_EUR_RATE", "0.9"))


def procesar_alquileres(ofertas, rate=DEFAULT_RATE):
    registros = []
    for entry in ofertas:
        # Extraer lista de resultados
        resultados = entry.get('resultados', {}).get('data', {}).get('search_results', [])
        ciudad = entry.get('ciudad_destino_aeropuerto')

        for res in resultados:
            proveedor = res.get('content', {}).get('supplier', {}).get('name', '')
            modelo = res.get('vehicle_info', {}).get('v_name', '')

            # Categoría y asientos
            label = res.get('vehicle_info', {}).get('label', '')
            categoria = label.split(' with')[0] if label else None
            asientos = res.get('vehicle_info', {}).get('seats')

            # Transmisión
            transmision = None
            for spec in res.get('content', {}).get('vehicleSpecs', []):
                if spec.get('icon', '').startswith("TRANSMISSION_"):
                    transmision = spec.get('text')
                    break

            # Precio USD → EUR
            pr = res.get('pricing_info', {}) or {}
            raw = pr.get('drive_away_price') if pr.get('drive_away_price') is not None else pr.get('price')
            try:
                usd = float(raw or 0)
            except (ValueError, TypeError):
                usd = 0.0
            precio = round(usd * rate, 2)

            registros.append({
                'Ciudad': ciudad,
                'Compañía': proveedor,
                'Vehículo': modelo,
                'Categoría': categoria,
                'Asientos': asientos,
                'Transmisión': transmision,
                'Precio': precio
            })

    return registros


def preparar_dataframe(registros):
    df = pd.DataFrame(registros)
    # Asegurar tipos sencillos
    df['Asientos'] = df['Asientos'].fillna(0).astype(int)
    df['Precio'] = df['Precio'].fillna(0.0)
    for col in ['Ciudad','Compañía','Vehículo','Categoría','Transmisión']:
        df[col] = df[col].fillna('').astype(str)
    return df


def insertar_bigquery(df):
    client = bigquery.Client(project=PROJECT_ID)
    table_id = f"{PROJECT_ID}.{DATASET}.{TABLE}"
    job = client.load_table_from_dataframe(df, table_id)
    job.result()  # Esperar a completar


def limpieza_alquileres(event, context):
    """
    Función Cloud Function trigger de Pub/Sub.
    Procesa el mensaje de suscripción y lo inserta en BigQuery.
    """
    logging.info("Evento recibido: %s", event)
    try:
        data_raw = base64.b64decode(event['data']).decode('utf-8')
        payload = json.loads(data_raw)
        # payload puede ser list o un dict
        mensajes = payload if isinstance(payload, list) else [payload]

        registros = procesar_alquileres(mensajes)
        df = preparar_dataframe(registros)
        insertar_bigquery(df)
        logging.info("Registros insertados: %d", len(df))
    except Exception:
        logging.exception("Error en limpieza_alquileres")
